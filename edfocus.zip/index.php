<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tags for Social Sharing -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="EdFocus Technologies - Your Entryway to Cutting-Edge E-Learning Technologies">
    <meta name="keywords" content="EdFocus, E-Learning, Education, Technology">
    <meta name="author" content="Your Name or Company Name">

    <!-- Open Graph (OG) Tags for Social Sharing -->
    <meta property="og:title" content="EdFocus Technologies">
    <meta property="og:description" content="Your entryway to a world of cutting-edge e-learning technologies.">
    <meta property="og:image" content="https://edfocustech.com/assets/images/logo/logo.webp">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://edfocustech.com">
    <meta property="og:type" content="website">

    <?php include('links.php'); ?>

</head>

<body class="custom-cursor">


    <div class="page-wrapper">

        <?php include('header.php'); ?>


        <section class="hero-banner-two" style="background-image: url(assets/images/shapes/banner-bg-2.png);">
            <div class="hero-banner-two__shape1 wow fadeInUp" data-wow-delay="200ms">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 133" fill="none">
                    <path
                        d="M94.4935 0.712799C95.597 1.45597 95.8869 2.96459 95.1423 4.09967C90.8319 10.6323 83.2497 10.1374 76.5614 9.69399C69.4714 9.22757 64.9825 9.21985 62.4529 13.0422C59.9198 16.8622 61.6846 20.9956 64.8949 27.3403C67.917 33.3156 71.3413 40.0873 67.0426 46.6025C62.722 53.1283 55.1468 52.6229 48.4642 52.1783C41.3675 51.7073 36.8752 51.6973 34.3351 55.5277C31.8031 59.3535 33.5668 63.4812 36.7805 69.8282C39.7969 75.8047 43.2246 82.5786 38.9259 89.0939C34.6089 95.6069 27.0313 95.105 20.3488 94.6604C13.252 94.1894 8.75971 94.1794 6.22663 97.9994C3.69678 101.837 5.4639 105.967 8.6811 112.316C11.7055 118.288 15.1322 125.056 10.8175 131.566C10.0648 132.705 8.54716 133.027 7.42646 132.287C6.27552 131.578 6.01023 130.025 6.76637 128.888C9.29946 125.068 7.53341 120.943 4.32412 114.605C1.29863 108.627 -2.12912 101.853 2.17894 95.3238C6.49598 88.8108 14.0678 89.3138 20.7527 89.7549C27.8494 90.2259 32.3417 90.2359 34.8748 86.4159C37.3953 82.5925 35.6282 78.4625 32.4202 72.1144C29.3981 66.139 25.9727 59.3616 30.284 52.8498C34.6057 46.3298 42.1798 46.8294 48.8624 47.274C55.9591 47.745 60.4514 47.755 62.9915 43.9246C65.512 40.1012 63.7449 35.9711 60.5369 29.623C57.5148 23.6477 54.0894 16.8703 58.403 10.355C62.7154 3.84893 70.2803 4.34734 76.956 4.78734C84.0575 5.25141 88.5532 5.26373 91.0854 1.42291C91.8381 0.28317 93.3523 -0.0406519 94.473 0.698994C94.4833 0.705897 94.4901 0.710498 94.4935 0.712799Z"
                        fill="#F57005" />
                </svg>
            </div><!-- banner-shape-one -->
            <div class="hero-banner-two__shape2 wow fadeInUp" data-wow-delay="250ms"><img
                    src="assets/images/shapes/banner-2-shape-2.png" alt="eduact"></div><!-- banner-shape-two -->
            <div class="hero-banner-two__shape3 wow fadeInUp" data-wow-delay="300ms"><img
                    src="assets/images/shapes/banner-2-shape-3.png" alt="eduact"></div><!-- banner-shape-three -->
            <div class="hero-banner-two__shape4 wow fadeInUp" data-wow-delay="350ms"><img
                    src="assets/images/shapes/banner-2-shape-4.png" alt="eduact"></div><!-- banner-shape-three -->
            <div class="hero-banner-two__shape5 wow fadeInUp" data-wow-delay="500ms"><img
                    src="assets/images/shapes/banner-2-shape-5.png" alt="eduact"></div><!-- banner-shape-three -->
            <div class="hero-banner-two__shape6 wow fadeInUp" data-wow-delay="500ms"><img
                    src="assets/images/shapes/code.png" alt="eduact"></div><!-- banner-shape-three -->
            <div class="hero-banner-two__bg-shape1 wow fadeInUp" data-wow-delay="500ms">


            </div><!-- banner-bg-shape -->
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 d-flex align-items-center">
                        <div class="hero-banner-two__content">
                            <h2 class="hero-banner-two__title wow fadeInUp" data-wow-delay="400ms">Empowering
                                Through Innovative Technology
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 237 79" fill="none">
                                    <path
                                        d="M120.802 78.9999C93.3177 78.9901 66.519 76.6913 40.6183 71.2164C33.8146 69.7778 27.1864 67.8613 20.9336 65.6899C8.33429 61.3129 2.40398 54.387 0.436736 45.829C-1.82029 36.0137 4.89365 28.338 15.6768 21.7577C36.4104 9.10449 62.3111 2.81096 91.281 0.67145C112.104 -0.865171 132.699 0.436178 153.233 2.55118C174.75 4.76666 194.01 10.1216 211.573 17.7262C221.331 21.9513 229.674 27.0342 234.314 33.911C238.922 40.7363 237.547 47.2333 230.613 53.1935C223.335 59.4478 213.328 63.7122 202.079 67.2192C190.664 70.7801 178.562 73.0936 166.351 75.1939C159.233 76.4193 151.706 76.8506 144.323 77.4486C136.507 78.0834 128.646 78.4926 120.802 78.9999ZM20.3418 22.5248C34.6513 16.3955 50.7443 12.7757 67.7067 10.3813C82.1101 8.34721 96.7093 7.11203 111.5 6.86205C126.283 6.61207 140.989 7.23701 155.547 8.8251C170.11 10.4132 184.195 13.0085 197.847 16.4298C210.291 19.5496 220.666 24.2526 228.282 31.0289C234.559 36.6142 234.637 42.3587 229.764 48.2798C226.801 51.8824 222.372 54.7203 217.123 57.1441C209.561 60.6389 201.247 63.3053 192.529 65.6335C183.468 68.0524 174.195 70.0915 164.62 71.5227C150.388 73.65 135.858 74.4661 121.186 74.1744C115.084 74.0543 108.921 74.1107 102.905 73.5911C88.5016 72.3486 74.3676 70.2924 60.5683 67.4986C47.5282 64.8591 34.9247 61.7099 24.3253 56.1957C15.7951 51.7598 10.4076 46.4172 10.1138 39.5012C10.0934 38.9767 10.9342 38.4375 11.3749 37.9057C12.2525 38.4204 13.2075 38.8983 13.9707 39.4693C14.2156 39.6531 13.9626 40.082 13.9177 40.3957C13.2524 44.8119 15.689 48.6719 20.3092 51.973C26.3538 56.2937 33.7942 59.5655 42.4305 61.8618C55.589 65.3615 69.2862 67.8392 83.2529 69.839C93.5258 71.3095 103.893 72.3609 114.472 72.6084C127.275 72.9074 139.981 72.3829 152.576 71.0203C174.085 68.6921 194.357 64.4596 212.271 56.7153C219.209 53.7155 225.237 50.2085 228.482 45.3193C231.588 40.6334 231.845 35.9329 226.613 31.7715C223.091 28.9727 219.017 26.3259 214.532 24.0835C207.014 20.324 198.043 18.0693 188.864 16.0769C167.453 11.4254 145.368 9.05057 122.651 8.71972C107.533 8.49915 92.534 9.32261 77.7348 11.1362C62.6539 12.9865 47.7975 15.3686 34.2064 19.9001C24.3335 23.1914 15.3992 27.1445 9.68932 33.2272C2.37949 41.0133 1.26118 48.8728 8.7057 56.8795C12.1096 60.5409 17.3053 63.0848 23.1703 65.1679C33.3493 68.7803 44.5651 70.8095 55.8992 72.5667C79.3429 76.1987 103.154 77.6986 127.361 76.7575C150.898 75.8434 173.754 73.2113 195.308 67.2069C207.304 63.8666 218.213 59.6782 226.515 53.3283C236.682 45.5496 236.735 36.0628 226.641 28.3037C220.331 23.4536 212.687 19.5594 203.998 16.3318C193.831 12.5551 183.231 9.33486 171.848 7.12918C154.555 3.779 136.662 2.38453 118.631 2.06838C97.8644 1.70567 77.445 3.06584 57.8991 7.88646C44.2712 11.2489 32.1167 15.8833 21.052 21.6425C20.6724 21.8386 20.6153 22.2552 20.3908 22.5567C19.8806 22.6498 19.3664 22.7405 18.8603 22.841C18.8317 22.8459 18.8521 22.939 18.848 22.9905C19.346 22.8361 19.8439 22.6817 20.3418 22.5248Z"
                                        fill="#F57005" />
                                </svg>
                                </span>
                            </h2>
                            <p class="hero-banner-two__text wow fadeInUp" data-wow-delay="500ms">
                                Empowering Peoples with Innovative Technology for a Brighter Future. Welcome to EdFocus
                                Technologies.
                            </p>
                            <div class="hero-banner-two__btn wow fadeInUp" data-wow-delay="600ms">
                                <a href="services.php" class="eduact-btn eduact-btn-second"><span
                                        class="eduact-btn__curve"></span>Our Services<i class="icon-arrow"></i></a>
                            </div><!-- banner-btn -->
                        </div><!-- banner-content -->
                    </div>
                    <div class="col-lg-6">
                        <div class="eduact-stretch-element-inside-column wow slideInRight" data-wow-delay="300ms">
                            <div class="hero-banner-two__stretch-image">
                                <img src="assets/images/resources/banner-2-2.jpg" alt="eduact">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Hero Banner End-->
        <!-- About Start -->
        <section class="about-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-two__thumb wow fadeInLeft" data-wow-delay="100ms"><!-- about thumb start -->
                            <div class="about-two__thumb__one eduact-tilt"
                                data-tilt-options='{ "glare": false, "maxGlare": 0, "maxTilt": 2, "speed": 700, "scale": 1 }'>
                                <img src="assets/images/about/about-2-1.jpg" alt="eduact">
                            </div><!-- /.about-thumb-one -->
                            <div class="about-two__thumb__two">
                                <img src="assets/images/about/about-2-2.jpg" alt="eduact">
                                <div class="about-two__thumb__two-icon"><span class="icon-business"></span></div>
                            </div><!-- /.about-thumb-two -->
                            <div class="about-two__fact">
                                <div class="about-two__fact__icon"><span class="icon-trophy"></span></div>
                                <div class="about-two__fact__content">
                                    <div class="about-two__fact__count">
                                        <span class="count-box">
                                            <span class="count-text" data-stop="10" data-speed="10"></span>+
                                        </span>
                                    </div><!-- /.fact-one__count -->
                                    <h3 class="about-two__fact__title">Awards</h3><!-- /.fact-one__title -->
                                </div>
                            </div><!-- /.fact-item -->
                            <div class="about-two__thumb__shape1 wow zoomIn" data-wow-delay="300ms">
                                <img src="assets/images/shapes/about-2-shape-1.png" alt="eduact">
                            </div><!-- /.about-shape-one -->
                            <div class="about-two__thumb__shape2 wow zoomIn" data-wow-delay="400ms">
                                <img src="assets/images/shapes/about-2-shape-2.png" alt="eduact">
                            </div><!-- /.about-shape-two -->
                            <div class="about-two__thumb__shape3 wow zoomIn" data-wow-delay="400ms">
                                <img src="assets/images/shapes/about-2-shape-3.png" alt="eduact">
                            </div><!-- /.about-shape-two -->
                            <div class="about-two__thumb__shape4 wow zoomIn" data-wow-delay="400ms">
                                <img src="assets/images/shapes/about-2-shape-4.png" alt="eduact">
                            </div><!-- /.about-shape-two -->
                        </div><!-- about thumb end -->
                    </div>
                    <div class="col-xl-6 wow fadeInRight" data-wow-delay="100ms">
                        <div class="about-two__content"><!-- about content start-->
                            <div class="section-title">
                                <h5 class="section-title__tagline">
                                    About Us
                                    <svg class="arrow-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 55 13">
                                        <g clip-path="url(#clip0_324_36194)">
                                            <path
                                                d="M10.5406 6.49995L0.700562 12.1799V8.56995L4.29056 6.49995L0.700562 4.42995V0.819946L10.5406 6.49995Z" />
                                            <path
                                                d="M25.1706 6.49995L15.3306 12.1799V8.56995L18.9206 6.49995L15.3306 4.42995V0.819946L25.1706 6.49995Z" />
                                            <path
                                                d="M39.7906 6.49995L29.9506 12.1799V8.56995L33.5406 6.49995L29.9506 4.42995V0.819946L39.7906 6.49995Z" />
                                            <path
                                                d="M54.4206 6.49995L44.5806 12.1799V8.56995L48.1706 6.49995L44.5806 4.42995V0.819946L54.4206 6.49995Z" />
                                        </g>
                                    </svg>
                                </h5>
                                <h2 class="section-title__title">Delivering Excellence through Innovative Technology.
                                </h2>
                            </div><!-- section-title -->
                            <p class="about-two__content__text">
                                At EdFocus, we're your gateway to cutting-edge e-learning technology. Our mission is to
                                enhance lifelong learning through innovative apps, designed collaboratively by
                                educators, developers, and designers. We believe in tailored, engaging education, backed
                                by research and catered to diverse needs. Join us on a journey toward a brighter,
                                smarter future.
                            </p>
                            <div class="about-two__box">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 295 125">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M86 0.0805664H58C25.9675 0.0805664 0 26.048 0 58.0806V79.5806C0 104.157 19.9233 124.081 44.5 124.081H46.5C69.9721 124.081 89 105.053 89 81.5806C89 58.1085 108.028 39.0806 131.5 39.0806H268C282.912 39.0806 295 26.9923 295 12.0806C295 5.45315 289.627 0.0805664 283 0.0805664H89H86Z" />
                                </svg>
                                <div class="about-two__box__icon"><span class="icon-Presentation"></span></div>
                                <h4 class="about-two__box__title">Our Mission</h4>
                                <p class="about-two__box__text">
                                    Empowering Peoples with Innovative Technology for a Brighter Future. Welcome to
                                    EdFocus Technologies.
                                </p>
                            </div><!-- /.icon-box -->
                            <ul class="about-two__lists clearfix">
                                <li><span class="icon-check"></span>Personalized Designing
                                </li>
                                <li><span class="icon-check"></span>Cutting-Edge Technology</li>
                                <li><span class="icon-check"></span>Collaborative Development</li>
                                <li><span class="icon-check"></span>Lifelong Support</li>
                            </ul>
                            <a href="about.php" class="eduact-btn"><span class="eduact-btn__curve"></span>Discover
                                More<i class="icon-arrow"></i></a><!-- /.btn -->
                        </div><!-- about content end -->
                    </div>
                </div>
            </div>
        </section>
        <!-- About End -->
        <!-- Service Start -->
        <section class="service-two">
            <div class="container">
                <div class="section-title text-center wow fadeInUp" data-wow-delay="100ms">
                    <h5 class="section-title__tagline">
                        Our Services
                        <svg class="arrow-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 55 13">
                            <g clip-path="url(#clip0_324_36194)">
                                <path
                                    d="M10.5406 6.49995L0.700562 12.1799V8.56995L4.29056 6.49995L0.700562 4.42995V0.819946L10.5406 6.49995Z" />
                                <path
                                    d="M25.1706 6.49995L15.3306 12.1799V8.56995L18.9206 6.49995L15.3306 4.42995V0.819946L25.1706 6.49995Z" />
                                <path
                                    d="M39.7906 6.49995L29.9506 12.1799V8.56995L33.5406 6.49995L29.9506 4.42995V0.819946L39.7906 6.49995Z" />
                                <path
                                    d="M54.4206 6.49995L44.5806 12.1799V8.56995L48.1706 6.49995L44.5806 4.42995V0.819946L54.4206 6.49995Z" />
                            </g>
                        </svg>
                    </h5>
                    <h2 class="section-title__title">Unlocking New Potential</h2>
                </div>

                <!-- section-title -->
                <div class="row">
                    <div class="col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                        <div class="service-two__item text-center">
                            <div class="service-two__wrapper">
                                <svg viewBox="0 0 303 117" fill="#F6F6F6" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="151" cy="-129" r="246" />
                                </svg>
                                <div class="service-two__icon">
                                    <img src="assets/images/icons/user-experience.png" alt="">
                                </div><!-- /.service-icon -->
                                <h3 class="service-two__title">
                                    <a href="services">UI/UX Designing</a>
                                </h3><!-- /.service-title -->
                                <p class="service-two__text">Elevate User Experiences with Exceptional UI/UX Designing
                                    with Edfocus</p>

                                <a class="service-two__rm" href="contact.php">Enquire<span
                                        class="icon-caret-right"></span></a>
                            </div>
                        </div><!-- /.service-card-one -->
                    </div>
                    <div class="col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                        <div class="service-two__item text-center">
                            <div class="service-two__wrapper">
                                <svg viewBox="0 0 303 117" fill="#F6F6F6" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="151" cy="-129" r="246" />
                                </svg>
                                <div class="service-two__icon">
                                    <img src="assets/images/icons/coding.png" alt="">
                                </div><!-- /.service-icon -->
                                <h3 class="service-two__title">
                                    <a href="services">Web Development</a>
                                </h3><!-- /.service-title -->
                                <p class="service-two__text">Transform Your Vision into a Dynamic Web Presence with
                                    Edfocus Development Service</p><!-- /.service-content -->
                                <a class="service-two__rm" href="contact.php">Enquire<span
                                        class="icon-caret-right"></span></a>
                            </div>
                        </div><!-- /.service-card-one -->
                    </div>
                    <div class="col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                        <div class="service-two__item text-center">
                            <div class="service-two__wrapper">
                                <svg viewBox="0 0 303 117" fill="#F6F6F6" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="151" cy="-129" r="246" />
                                </svg>
                                <div class="service-two__icon">
                                    <img src="assets/images/icons/graphic-design.png" alt="">
                                </div><!-- /.service-icon -->
                                <h3 class="service-two__title">
                                    <a href="services">Graphic Designing</a>
                                </h3><!-- /.service-title -->
                                <p class="service-two__text">Captivate Audiences with Stunning Graphic Designs by
                                    Edfocus Designers</p><!-- /.service-content -->
                                <a class="service-two__rm" href="contact.php">Enquire<span
                                        class="icon-caret-right"></span></a>
                            </div>
                        </div><!-- /.service-card-one -->
                    </div>
                    <div class="col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="500ms">
                        <div class="service-two__item text-center">
                            <div class="service-two__wrapper">
                                <svg viewBox="0 0 303 117" fill="#F6F6F6" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="151" cy="-129" r="246" />
                                </svg>
                                <div class="service-two__icon">
                                    <img src="assets/images/icons/setting.png" alt="">
                                </div><!-- /.service-icon -->
                                <h3 class="service-two__title">
                                    <a href="about.html">Software Consulting</a>
                                </h3><!-- /.service-title -->
                                <p class="service-two__text">Unlocking the Full Potential of Your Software with Our
                                    Expert Consulting Services</p><!-- /.service-content -->
                                <a class="service-two__rm" href="contact.php">Enquire<span
                                        class="icon-caret-right"></span></a>
                            </div>
                        </div><!-- /.service-card-one -->
                    </div>
                </div>
            </div>
        </section>
        <!-- Service End -->
        <!-- Counter Start -->
        <section class="fact-one" style="background-image: url(assets/images/shapes/fact-bg-1.png);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                        <div class="fact-one__item text-center">
                            <svg viewBox="0 0 303 181" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="1.5" y="2.00049" width="300" height="177" rx="7" stroke="#4F5DE4"
                                    stroke-width="3" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-dasharray="20 20" />
                            </svg>
                            <div class="fact-one__count">
                                <span class="count-box">
                                    <span class="count-text" data-stop="100" data-speed="1500"></span>
                                </span>+
                            </div><!-- /.fact-one__count -->
                            <h3 class="fact-one__title">Projects Completed</h3><!-- /.fact-one__title -->
                        </div><!-- /.fact-item -->
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                        <div class="fact-one__item text-center">
                            <svg viewBox="0 0 303 181" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="1.5" y="2.00049" width="300" height="177" rx="7" stroke="#4F5DE4"
                                    stroke-width="3" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-dasharray="20 20" />
                            </svg>
                            <div class="fact-one__count">
                                <span class="count-box">
                                    <span class="count-text" data-stop="12" data-speed="1500"></span>
                                </span>+
                            </div><!-- /.fact-one__count -->
                            <h3 class="fact-one__title">IT SPECIALISTS</h3><!-- /.fact-one__title -->
                        </div><!-- /.fact-item -->
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                        <div class="fact-one__item text-center">
                            <svg viewBox="0 0 303 181" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="1.5" y="2.00049" width="300" height="177" rx="7" stroke="#4F5DE4"
                                    stroke-width="3" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-dasharray="20 20" />
                            </svg>
                            <div class="fact-one__count">
                                <span class="count-box">
                                    <span class="count-text" data-stop="100" data-speed="1500"></span>
                                </span>+
                            </div><!-- /.fact-one__count -->
                            <h3 class="fact-one__title">SATISFIED CLIENTS</h3><!-- /.fact-one__title -->
                        </div><!-- /.fact-item -->
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                        <div class="fact-one__item text-center">
                            <svg viewBox="0 0 303 181" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="1.5" y="2.00049" width="300" height="177" rx="7" stroke="#4F5DE4"
                                    stroke-width="3" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-dasharray="20 20" />
                            </svg>
                            <div class="fact-one__count">
                                <span class="count-box">
                                    <span class="count-text" data-stop="238" data-speed="1500"></span>
                                </span>+
                            </div><!-- /.fact-one__count -->
                            <h3 class="fact-one__title">SMART SOLUTIONS</h3><!-- /.fact-one__title -->
                        </div><!-- /.fact-item -->
                    </div>
                </div>
            </div>
        </section>
        <!-- Counter End -->


        <section class="testimonial-two" style="background-image: url(assets/images/shapes/testimonial-bg-2.png);">
            <div class="container">
                <div class="section-title text-center">
                    <h5 class="section-title__tagline">
                        Testimonial
                        <svg class="arrow-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 55 13">
                            <g clip-path="url(#clip0_324_36194)">
                                <path
                                    d="M10.5406 6.49995L0.700562 12.1799V8.56995L4.29056 6.49995L0.700562 4.42995V0.819946L10.5406 6.49995Z" />
                                <path
                                    d="M25.1706 6.49995L15.3306 12.1799V8.56995L18.9206 6.49995L15.3306 4.42995V0.819946L25.1706 6.49995Z" />
                                <path
                                    d="M39.7906 6.49995L29.9506 12.1799V8.56995L33.5406 6.49995L29.9506 4.42995V0.819946L39.7906 6.49995Z" />
                                <path
                                    d="M54.4206 6.49995L44.5806 12.1799V8.56995L48.1706 6.49995L44.5806 4.42995V0.819946L54.4206 6.49995Z" />
                            </g>
                        </svg>
                    </h5>
                    <h2 class="section-title__title">What Our clients Says</h2>
                </div><!-- section-title -->
                <div class="testimonial-two__carousel eduact-owl__carousel owl-with-shadow owl-theme owl-carousel"
                    data-owl-options='{
            "items": 3,
            "margin": 30,
            "smartSpeed": 700,
            "loop":true,
            "autoplay": true,
            "center": true,
            "nav":true,
            "dots":false,
            "navText": ["<span class=\"icon-arrow-left\"></span>","<span class=\"icon-arrow\"></span>"],
            "responsive":{
                "0":{
                    "items":1,
                    "margin": 0
                },
                "700":{
                    "items": 1
                },
                "992":{
                    "items": 3
                },
                "1200":{
                    "margin": 36,
                    "items": 3
                }
            }
            }'>
                    <!-- Testimonial Item -->

                    <div class="item">
                        <div class="testimonial-two__item">
                            <div class="testimonial-two__item-inner"
                                style="background-image: url(assets/images/shapes/testimonial-shape-2.png);">
                                <div class="testimonial-two__ratings">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <div class="testimonial-two__quote">
                                    “They do their very best to make sure you succeed. If there’s an issue, they step in
                                    immediately.”
                                </div><!-- testimonial-quote -->
                                <div class="testimonial-two__meta">

                                    <h5 class="testimonial-two__title">Amit Patel</h5>
                                    <span class="testimonial-two__designation">Mumbai</span>
                                </div><!-- testimonial-meta -->
                                <svg viewBox="0 0 416 249" xmlns="http://www.w3.org/2000/svg">
                                    <g filter="url(#filter0_d_324_36064)">
                                        <path
                                            d="M296.443 526.351C291.626 517.219 286.22 508.4 280.351 499.907C274.064 490.803 267.257 482.07 260.072 473.662C252.166 464.412 243.802 455.551 235.132 447.015C225.525 437.563 215.537 428.493 205.305 419.728C193.907 409.977 182.21 400.591 170.293 391.477C157.025 381.325 143.506 371.508 129.809 361.934C114.574 351.278 99.1373 340.919 83.5681 330.773C66.2815 319.506 48.8344 308.493 31.2774 297.659C11.8453 285.67 -7.71089 273.899 -27.3627 262.269C-49.0253 249.452 -70.8004 236.801 -92.632 224.268C-112.751 212.719 -132.553 200.599 -151.773 187.605C-167.672 176.859 -183.186 165.529 -198.079 153.411C-210.223 143.528 -221.954 133.126 -233.015 122.043C-242.024 113.01 -250.588 103.518 -258.425 93.4561C-264.651 85.4701 -270.424 77.1028 -275.483 68.3262C-279.503 61.3457 -283.079 54.0865 -285.969 46.5676C-288.192 40.7857 -290.021 34.8356 -291.27 28.7606C-292.209 24.2029 -292.822 19.5763 -292.986 14.9289C-293.101 11.7908 -293.016 8.64358 -292.628 5.53246C-292.424 3.91736 -292.165 2.29171 -291.728 0.72597C-291.679 0.529505 -291.617 0.330416 -291.559 0.139576C-291.56 1.65120 -291.422 3.17245 -291.258 4.67452C-290.799 8.90587 -289.976 13.0825 -288.939 17.2111C-287.309 23.703 -285.103 30.0422 -282.479 36.194C-278.927 44.5375 -274.604 52.5471 -269.706 60.1738C-263.507 69.8349 -256.393 78.8972 -248.649 87.3719C-238.942 97.9926 -228.245 107.691 -216.918 116.571C-203.009 127.487 -188.159 137.180 -172.790 145.896C-153.752 156.686 -133.883 165.972 -113.594 174.141C-88.9088 184.080 -63.5671 192.361 -37.9282 199.441C-11.3405 206.779 15.589 212.887 42.7613 217.66C67.4471 221.999 92.326 225.272 117.29 227.514C141.053 229.653 164.9 230.869 188.764 231.226C211.313 231.559 233.873 231.113 256.392 229.925C277.174 228.838 297.929 227.116 318.614 224.801C337.536 222.679 356.4 220.056 375.184 216.945C391.68 214.211 408.11 211.094 424.452 207.59C438.374 204.605 452.242 201.341 466.025 197.777C476.913 194.966 487.745 191.97 498.512 188.749C506.072 186.491 513.591 184.133 521.068 181.624C524.972 180.313 528.87 178.974 532.737 177.541C533.207 177.365 533.677 177.189 534.148 177.014">
                                        </path>
                                    </g>
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-two__item">
                            <div class="testimonial-two__item-inner"
                                style="background-image: url(assets/images/shapes/testimonial-shape-2.png);">
                                <div class="testimonial-two__ratings">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <div class="testimonial-two__quote">
                                    “We’re 100% satisfied with their work, and Edfocus has exceeded our expectations.”
                                </div><!-- testimonial-quote -->
                                <div class="testimonial-two__meta">

                                    <h5 class="testimonial-two__title">Priya Sharma</h5>
                                    <span class="testimonial-two__designation">Delhi</span>
                                </div><!-- testimonial-meta -->
                                <svg viewBox="0 0 416 249" xmlns="http://www.w3.org/2000/svg">
                                    <g filter="url(#filter0_d_324_36064)">
                                        <path
                                            d="M296.443 526.351C291.626 517.219 286.22 508.4 280.351 499.907C274.064 490.803 267.257 482.07 260.072 473.662C252.166 464.412 243.802 455.551 235.132 447.015C225.525 437.563 215.537 428.493 205.305 419.728C193.907 409.977 182.21 400.591 170.293 391.477C157.025 381.325 143.506 371.508 129.809 361.934C114.574 351.278 99.1373 340.919 83.5681 330.773C66.2815 319.506 48.8344 308.493 31.2774 297.659C11.8453 285.67 -7.71089 273.899 -27.3627 262.269C-49.0253 249.452 -70.8004 236.801 -92.632 224.268C-112.751 212.719 -132.553 200.599 -151.773 187.605C-167.672 176.859 -183.186 165.529 -198.079 153.411C-210.223 143.528 -221.954 133.126 -233.015 122.043C-242.024 113.01 -250.588 103.518 -258.425 93.4561C-264.651 85.4701 -270.424 77.1028 -275.483 68.3262C-279.503 61.3457 -283.079 54.0865 -285.969 46.5676C-288.192 40.7857 -290.021 34.8356 -291.27 28.7606C-292.209 24.2029 -292.822 19.5763 -292.986 14.9289C-293.101 11.7908 -293.016 8.64358 -292.628 5.53246C-292.424 3.91736 -292.165 2.29171 -291.728 0.72597C-291.679 0.529505 -291.617 0.330416 -291.559 0.139576C-291.56 1.65120 -291.422 3.17245 -291.258 4.67452C-290.799 8.90587 -289.976 13.0825 -288.939 17.2111C-287.309 23.703 -285.103 30.0422 -282.479 36.194C-278.927 44.5375 -274.604 52.5471 -269.706 60.1738C-263.507 69.8349 -256.393 78.8972 -248.649 87.3719C-238.942 97.9926 -228.245 107.691 -216.918 116.571C-203.009 127.487 -188.159 137.180 -172.790 145.896C-153.752 156.686 -133.883 165.972 -113.594 174.141C-88.9088 184.080 -63.5671 192.361 -37.9282 199.441C-11.3405 206.779 15.589 212.887 42.7613 217.66C67.4471 221.999 92.326 225.272 117.29 227.514C141.053 229.653 164.9 230.869 188.764 231.226C211.313 231.559 233.873 231.113 256.392 229.925C277.174 228.838 297.929 227.116 318.614 224.801C337.536 222.679 356.4 220.056 375.184 216.945C391.68 214.211 408.11 211.094 424.452 207.59C438.374 204.605 452.242 201.341 466.025 197.777C476.913 194.966 487.745 191.97 498.512 188.749C506.072 186.491 513.591 184.133 521.068 181.624C524.972 180.313 528.87 178.974 532.737 177.541C533.207 177.365 533.677 177.189 534.148 177.014">
                                        </path>
                                    </g>
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="testimonial-two__item">
                            <div class="testimonial-two__item-inner"
                                style="background-image: url(assets/images/shapes/testimonial-shape-2.png);">
                                <div class="testimonial-two__ratings">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <div class="testimonial-two__quote">
                                    “They recognize that our success is in everyone’s interest, and they work hard to
                                    help us get there.” </div><!-- testimonial-quote -->
                                <div class="testimonial-two__meta">

                                    <h5 class="testimonial-two__title">Arun</h5>
                                    <span class="testimonial-two__designation">Kerala</span>
                                </div><!-- testimonial-meta -->
                                <svg viewBox="0 0 416 249" xmlns="http://www.w3.org/2000/svg">
                                    <g filter="url(#filter0_d_324_36064)">
                                        <path
                                            d="M296.443 526.351C291.626 517.219 286.22 508.4 280.351 499.907C274.064 490.803 267.257 482.07 260.072 473.662C252.166 464.412 243.802 455.551 235.132 447.015C225.525 437.563 215.537 428.493 205.305 419.728C193.907 409.977 182.21 400.591 170.293 391.477C157.025 381.325 143.506 371.508 129.809 361.934C114.574 351.278 99.1373 340.919 83.5681 330.773C66.2815 319.506 48.8344 308.493 31.2774 297.659C11.8453 285.67 -7.71089 273.899 -27.3627 262.269C-49.0253 249.452 -70.8004 236.801 -92.632 224.268C-112.751 212.719 -132.553 200.599 -151.773 187.605C-167.672 176.859 -183.186 165.529 -198.079 153.411C-210.223 143.528 -221.954 133.126 -233.015 122.043C-242.024 113.01 -250.588 103.518 -258.425 93.4561C-264.651 85.4701 -270.424 77.1028 -275.483 68.3262C-279.503 61.3457 -283.079 54.0865 -285.969 46.5676C-288.192 40.7857 -290.021 34.8356 -291.27 28.7606C-292.209 24.2029 -292.822 19.5763 -292.986 14.9289C-293.101 11.7908 -293.016 8.64358 -292.628 5.53246C-292.424 3.91736 -292.165 2.29171 -291.728 0.72597C-291.679 0.529505 -291.617 0.330416 -291.559 0.139576C-291.56 1.65120 -291.422 3.17245 -291.258 4.67452C-290.799 8.90587 -289.976 13.0825 -288.939 17.2111C-287.309 23.703 -285.103 30.0422 -282.479 36.194C-278.927 44.5375 -274.604 52.5471 -269.706 60.1738C-263.507 69.8349 -256.393 78.8972 -248.649 87.3719C-238.942 97.9926 -228.245 107.691 -216.918 116.571C-203.009 127.487 -188.159 137.180 -172.790 145.896C-153.752 156.686 -133.883 165.972 -113.594 174.141C-88.9088 184.080 -63.5671 192.361 -37.9282 199.441C-11.3405 206.779 15.589 212.887 42.7613 217.66C67.4471 221.999 92.326 225.272 117.29 227.514C141.053 229.653 164.9 230.869 188.764 231.226C211.313 231.559 233.873 231.113 256.392 229.925C277.174 228.838 297.929 227.116 318.614 224.801C337.536 222.679 356.4 220.056 375.184 216.945C391.68 214.211 408.11 211.094 424.452 207.59C438.374 204.605 452.242 201.341 466.025 197.777C476.913 194.966 487.745 191.97 498.512 188.749C506.072 186.491 513.591 184.133 521.068 181.624C524.972 180.313 528.87 178.974 532.737 177.541C533.207 177.365 533.677 177.189 534.148 177.014">
                                        </path>
                                    </g>
                                </svg>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </section>

        <section class="contact-one">
            <div class="container wow fadeInUp" data-wow-delay="300ms">
                <div class="section-title  text-center">
                    <h5 class="section-title__tagline">
                        Contact with Us
                        <svg class="arrow-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 55 13">
                            <g clip-path="url(#clip0_324_36194)">
                                <path
                                    d="M10.5406 6.49995L0.700562 12.1799V8.56995L4.29056 6.49995L0.700562 4.42995V0.819946L10.5406 6.49995Z" />
                                <path
                                    d="M25.1706 6.49995L15.3306 12.1799V8.56995L18.9206 6.49995L15.3306 4.42995V0.819946L25.1706 6.49995Z" />
                                <path
                                    d="M39.7906 6.49995L29.9506 12.1799V8.56995L33.5406 6.49995L29.9506 4.42995V0.819946L39.7906 6.49995Z" />
                                <path
                                    d="M54.4206 6.49995L44.5806 12.1799V8.56995L48.1706 6.49995L44.5806 4.42995V0.819946L54.4206 6.49995Z" />
                            </g>
                        </svg>
                    </h5>
                    <h2 class="section-title__title">Feel Free to Write us Anytime</h2>
                </div><!-- section-title -->
                <div class="contact-one__form-box  text-center">
                    <form method="POST" class="form">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="contact-one__input-box">
                                    <input type="text" placeholder="Your Name" name="name" id="name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="contact-one__input-box">
                                    <input type="email" placeholder="Email Address" name="email" id="email">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="contact-one__input-box">
                                    <input type="text" placeholder="Phone" name="phone" id="phone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="contact-one__input-box">
                                    <input type="text" placeholder="Subject" name="subject" id="subject">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="contact-one__input-box text-message-box">
                                    <textarea name="message" id="message" placeholder="Write a Message"></textarea>
                                </div>
                                <div class="contact-one__btn-box">
                                    <button type="submit" onclick="Send()" class="eduact-btn eduact-btn-second"><span
                                            class="eduact-btn__curve"></span>Send Message<i
                                            class="icon-arrow"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <script src="https://smtpjs.com/v3/smtp.js"></script>
                    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


                    <script>

                        function Send() {
                            event.preventDefault();


                            var name = document.getElementById("name").value;
                            var email = document.getElementById("email").value;
                            var phone = document.getElementById("phone").value;
                            var subject = document.getElementById("subject").value;
                            var message = document.getElementById("message").value;

                            // Validation: Check if any of the required fields is empty
                            if (!name || !email || !phone || !subject || !message) {
                                swal("Error", "Please fill in all the required fields.", "error");
                                return; // Stop execution if validation fails
                            }

                            var body = "name: " + name + "<br/> email:" + email + "<br/> contact:" + phone + "<br/> subject:" + subject + "<br/> Message:" + message;

                            console.log(body);
                            Email.send({
                                Host: "smtp.elasticemail.com",
                                Username: "hisham072001@gmail.com",
                                Password: "7ED22F18105460EE0603D607841658FD2D09",
                                To: 'hisham1off@gmail.com',
                                From: "hisham072001@gmail.com",
                                Subject: "Edfocus Contact Form Enquiry",
                                Body: body
                            }).then(
                                message => {
                                    if (message == 'OK') {
                                        swal("Successful", "Your message has been send!", "success");

                                    }

                                }
                            );
                        }
                    </script>
                </div>
            </div>
        </section>

        <?php include('footer.php'); ?>

    </div><!-- /.page-wrapper -->

    <?php include('scripts.php'); ?>

</body>


</html>